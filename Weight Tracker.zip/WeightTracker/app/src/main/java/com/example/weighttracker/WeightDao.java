package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface WeightDao {

    @Query("SELECT * FROM weights WHERE username = :username ORDER BY date_ms ASC")
    public List<Weight> getWeights(String username);

    @Query("SELECT * FROM weights WHERE id = :id")
    public List<Weight> getWeightByID(long id);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertWeight(Weight weight);

    @Update
    public void updateWeight(Weight weight);

    @Delete
    public void deleteWeight(Weight weight);

}
