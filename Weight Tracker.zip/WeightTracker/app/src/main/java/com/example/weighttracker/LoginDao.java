package com.example.weighttracker;

import androidx.room.ColumnInfo;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface LoginDao {

    @Query("SELECT * FROM login ORDER BY username ASC")
    public List<Login> getLogins();

    @Query("SELECT * FROM login WHERE username = :username")
    public List<Login> loginExists(String username);

    @Query("SELECT * FROM login WHERE username = :username AND password = :password")
    public List<Login> login(String username, String password);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    public void insertLogin(Login login);

    @Update
    public void updateLogin(Login login);

    @Delete
    public void deleteLogin(Login login);
}