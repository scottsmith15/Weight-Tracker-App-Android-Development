package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.List;

public class LoginActivity extends AppCompatActivity {

    private EditText mUsernameEdit;
    private EditText mPasswordEdit;
    private Button mLoginButton;
    private Button mNewAccountButton;
    private WeightDatabase mWeightDb;
    private String mUsername;
    private String mPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // toggle night mode
        //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        setContentView(R.layout.activity_login);
        mUsernameEdit = findViewById(R.id.usernameEdit);
        mPasswordEdit = findViewById(R.id.passwordEdit);
        mLoginButton = findViewById(R.id.loginButton);
        mNewAccountButton = findViewById(R.id.newAccountButton);

        // Singleton
        mWeightDb = WeightDatabase.getInstance(getApplicationContext());

    }

    // Method to log in to app
    public void login(View view) {
        if (mUsernameEdit.getText().length() != 0) {
            mUsername = mUsernameEdit.getText().toString();
            if (mPasswordEdit.getText().length() != 0) {
                mPassword = mPasswordEdit.getText().toString();
                if (mWeightDb.loginDao().loginExists(mUsername).size() == 1) {
                    if (mWeightDb.loginDao().login(mUsername, mPassword).size() == 1) {
                        Intent intent = new Intent(this, DetailsActivity.class);
                        intent.putExtra(DetailsActivity.EXTRA_USERNAME, mUsername);
                        startActivity(intent);
                    }
                    else {
                        Toast.makeText(getApplicationContext(), "Username or password is incorrect.",
                                Toast.LENGTH_LONG).show();
                    }
                }

                else {
                    Toast.makeText(getApplicationContext(), "Username or password is incorrect.",
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    }


    // Method to create a new account
    public void createNewAccount(View view) {
        if (mUsernameEdit.getText().length() != 0) {
            mUsername = mUsernameEdit.getText().toString();
            if (mPasswordEdit.getText().length() != 0) {
                mPassword = mPasswordEdit.getText().toString();
                if (mWeightDb.loginDao().loginExists(mUsername).size() == 0) {
                    Login login = new Login(mUsername, mPassword);
                    mWeightDb.loginDao().insertLogin(login);
                    Toast.makeText(getApplicationContext(), "Account created successfully.",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    Toast.makeText(getApplicationContext(), "User already exists.",
                            Toast.LENGTH_LONG).show();
                }
            }
        }
    }



}