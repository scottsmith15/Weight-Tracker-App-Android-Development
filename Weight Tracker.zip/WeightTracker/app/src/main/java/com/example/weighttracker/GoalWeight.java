package com.example.weighttracker;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "goal_weight",
        foreignKeys = @ForeignKey(entity = Login.class,
                parentColumns = "username",
                childColumns = "username"))
public class GoalWeight {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    private long mId;
    @ColumnInfo(name = "goal")
    private int mGoalWeight;
    @ColumnInfo(name = "username")
    private String mUsername;

    public GoalWeight(){
    }

    public GoalWeight(int goal, String username) {
        mGoalWeight = goal;
        mUsername = username;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setGoalWeight(int goal) {
        mGoalWeight = goal;
    }

    public int getGoalWeight() {
        return mGoalWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }
}
