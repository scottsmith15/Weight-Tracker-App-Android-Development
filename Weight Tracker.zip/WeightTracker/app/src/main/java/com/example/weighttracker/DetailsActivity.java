package com.example.weighttracker;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Observable;
import java.util.Observer;

public class DetailsActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "com.example.weighttracker.username";
    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS = 0;
    private WeightDatabase mWeightDb;
    private CustomAdapter mCustomAdapter;
    private RecyclerView mRecyclerView;
    private TextView mGoalWeightNumberText;
    private EditText mAddWeightEdit;
    private EditText mGoalWeightEdit;
    private GoalWeight mMyGoalWeight;
    private String mUsername;
    private ArrayList<HashMap<String, String>> mArrayList;
    private HashMap<String, String> mWeightHashMap;
    private Button mEditButton;
    private EditFragment mEditFragment;
    private boolean mEditActive = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // grab username from login activity
        Intent intent = getIntent();
        mUsername = intent.getCharSequenceExtra(EXTRA_USERNAME).toString();

        // array
        mArrayList = new ArrayList<HashMap<String, String>>();
        // Singleton
        mWeightDb = WeightDatabase.getInstance(getApplicationContext());

        // initialize some data for initial display (testing)
        Weight new_weight = new Weight(120, mUsername);
        GoalWeight new_goal_weight = new GoalWeight(150, mUsername);
        mWeightDb.weightDao().insertWeight(new_weight);
        mWeightDb.goalWeightDao().insertGoalWeight(new_goal_weight);

        mRecyclerView = findViewById(R.id.recyclerView);
        mEditButton = findViewById(R.id.editButton);
        mGoalWeightNumberText = findViewById(R.id.goalWeightNumberText);
        mAddWeightEdit = findViewById(R.id.addWeightEdit);
        mGoalWeightEdit = findViewById(R.id.goalWeightEdit);

        // display user data
        refreshDataGrid();
    }

    // on click for selecting edit item button
    public void editItem(View view) {

        mEditActive = !mEditActive;
        if (mEditActive && mCustomAdapter.getSelectedItemPosition() != RecyclerView.NO_POSITION) {
            //Create bundle for selected info
            Bundle bundle = new Bundle();
            bundle.putString("date", mCustomAdapter.getItem().get("DATE"));
            bundle.putString("weight", mCustomAdapter.getItem().get("WEIGHT"));

            // Begin a new FragmentTransaction for adding an EditFragment
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

            // Add the EditFragment to the fragment container in the activity layout
            mEditFragment = new EditFragment();
            mEditFragment.setArguments(bundle);
            fragmentTransaction.add(R.id.editFragment, mEditFragment);
            fragmentTransaction.commit();
        }
        else {
            // close fragment
            getSupportFragmentManager().beginTransaction().
                    remove(getSupportFragmentManager().findFragmentById(R.id.editFragment)).commit();
        }

    }

    // confirm data updates via edit fragment
    public void confirmChanges(View view) {
        Bundle bundle;
        try {
            bundle = mEditFragment.returnUserInput();
            // update date and weight in database
            Weight weight = mWeightDb.weightDao().getWeightByID(Long.parseLong(mCustomAdapter.getItem().get("ID"))).
                    get(0);
            weight.setDate(bundle.getString("date"));

            SimpleDateFormat f = new SimpleDateFormat("MM/dd/yy");
            try {
                Date d = f.parse(weight.getDate());
                long milliseconds = d.getTime();
                weight.setDateMs(milliseconds);
            } catch (ParseException e) {
                e.printStackTrace();
            }

            weight.setWeight(Integer.parseInt(bundle.getString("weight")));
            mWeightDb.weightDao().updateWeight(weight);
        }
        catch (Exception e){
            Toast.makeText(getApplicationContext(), "Item update failed.",
                    Toast.LENGTH_LONG).show();
        }

        // refresh display
        refreshDataGrid();
        mEditButton.setEnabled(false);
        // close fragment
        mEditActive = !mEditActive;
        getSupportFragmentManager().beginTransaction().
                remove(getSupportFragmentManager().findFragmentById(R.id.editFragment)).commit();

    }

    // on click for deleting a row from database
    public void deleteRow(View view) {
        Weight weight = mWeightDb.weightDao().getWeightByID(Long.parseLong(mCustomAdapter.getItem().get("ID"))).
                get(0);

        mWeightDb.weightDao().deleteWeight(weight);
        refreshDataGrid();
        mEditButton.setEnabled(false);
        // close fragment
        mEditActive = !mEditActive;
        getSupportFragmentManager().beginTransaction().
                remove(getSupportFragmentManager().findFragmentById(R.id.editFragment)).commit();
    }

    // on click for adding a weight value to database
    public void addWeight(View view) {
        if (mAddWeightEdit.length() > 0) {
            Weight weight = new Weight(Integer.parseInt(mAddWeightEdit.getText().toString()), mUsername);
            mWeightDb.weightDao().insertWeight(weight);
            refreshDataGrid();
        }
    }

    // on click for changing goal weight value
    public void resetGoalWeight(View view) {
        if (mGoalWeightEdit.length() > 0) {
            GoalWeight goalWeight = new GoalWeight(Integer.parseInt(mGoalWeightEdit.getText().toString()), mUsername);
            mWeightDb.goalWeightDao().insertGoalWeight(goalWeight);
            // refresh data
            refreshDataGrid();
        }
    }

    // refresh details activity with new data
    public void refreshDataGrid() {
        // array
        mArrayList = new ArrayList<HashMap<String, String>>();
        // Singleton
        mWeightDb = WeightDatabase.getInstance(getApplicationContext());
        List<Weight> my_weights = mWeightDb.weightDao().getWeights(mUsername);
        mMyGoalWeight = mWeightDb.goalWeightDao().getLatestGoalWeight(mUsername).get(0);
        // display goal weight
        mGoalWeightNumberText.setText(String.valueOf(mMyGoalWeight.getGoalWeight()));

        for (int i = 0; i < my_weights.size(); i++) {
            mWeightHashMap = new HashMap<String, String>();
            mWeightHashMap.put("ID", String.valueOf(my_weights.get(i).getId()));
            mWeightHashMap.put("DATE", my_weights.get(i).getDate());
            mWeightHashMap.put("WEIGHT", String.valueOf(my_weights.get(i).getWeight()));
            mArrayList.add(mWeightHashMap);

            if (Integer.parseInt(mWeightHashMap.get("WEIGHT")) == mMyGoalWeight.getGoalWeight()) {
                Toast.makeText(getApplicationContext(), "Goal Weight Reached!",
                        Toast.LENGTH_LONG).show();
                sendSMSMessage();
            }
        }

        // Create 1 grid layout column
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 1);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        mCustomAdapter = new CustomAdapter(mArrayList, mEditButton);
        mRecyclerView.setAdapter(mCustomAdapter);

    }

    // toggle SMS notifications
    public void allowNotifications(View view) {
        sendSMSMessage();
    }

    // send SMS text message
    protected void sendSMSMessage() {

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.SEND_SMS)) {
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        MY_PERMISSIONS_REQUEST_SEND_SMS);
            }
        }
    }

    // overridden method for requesting SMS permissions
    @Override
    public void onRequestPermissionsResult(int requestCode,String permissions[], int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_SEND_SMS: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage("(650) 555-1212", null, "Goal Weight Reached!", null, null);
                    Toast.makeText(getApplicationContext(), "SMS sent.",
                            Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(getApplicationContext(),
                            "SMS failed, please try again.", Toast.LENGTH_LONG).show();
                    return;
                }
            }
        }

    }
}