package com.example.weighttracker;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface GoalWeightDao {

    @Query("SELECT * FROM goal_weight WHERE username = :username")
    public List<GoalWeight> getGoalWeight(String username);

    @Query("SELECT * FROM goal_weight WHERE username = :username AND id = (SELECT MAX(id) FROM goal_weight)")
    public List<GoalWeight> getLatestGoalWeight(String username);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertGoalWeight(GoalWeight weight);

    @Update
    public void updateGoalWeight(GoalWeight weight);

    @Delete
    public void deleteGoalWeight(GoalWeight weight);

}

