package com.example.weighttracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class EditFragment extends Fragment {
    private EditText mDateEdit;
    private EditText mWeightEdit;

    public EditFragment() {
        super(R.layout.fragment_edit);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_edit, container, false);

        mDateEdit = rootView.findViewById(R.id.dateEditFragment);
        mWeightEdit = rootView.findViewById(R.id.weightEditFragment);
        return rootView;
    }

    // grab arguments from details activity
    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        String date = getArguments().getString("date");
        String weight = requireArguments().getString("weight");
        mDateEdit.setHint(date);
        mWeightEdit.setHint(weight);

    }

    // return item updates to details activity
    public Bundle returnUserInput() {
        Bundle bundle = new Bundle();
        if (mDateEdit.getText().length() > 0) {
            bundle.putString("date", mDateEdit.getText().toString());
        }
        if (mWeightEdit.getText().length() > 0) {
            bundle.putString("weight", mWeightEdit.getText().toString());
        }
        return bundle;
    }
}
