package com.example.weighttracker;

import android.content.Context;
/*import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.content.Context;*/
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Weight.class, GoalWeight.class, Login.class}, version = 1)
public abstract class WeightDatabase extends RoomDatabase {

    private static final String DATABASE_NAME = "weight.db";

    private static WeightDatabase mWeightDatabase;

    // Singleton
    public static WeightDatabase getInstance(Context context) {
        if (mWeightDatabase == null) {
            mWeightDatabase = Room.databaseBuilder(context, WeightDatabase.class,
                    DATABASE_NAME).allowMainThreadQueries().build();
        }
        return mWeightDatabase;
    }

    public abstract WeightDao weightDao();
    public abstract LoginDao loginDao();
    public abstract GoalWeightDao goalWeightDao();

    /* private WeightDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    private static final class LoginTable {
        private static final String TABLE = "login";
        // username primary key
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    private static final class WeightTable {
        private static final String TABLE = "weights";
        // date primary key
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
        // Having a 3rd table for one attribute adds unnecessary complexity to database
        private static final String COL_GOAL_WEIGHT = "goalWeight";
        // username foreign key
        private static final String COL_USERNAME = "username";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create login table
        db.execSQL("create table " + LoginTable.TABLE + " (" +
                LoginTable.COL_USERNAME + " primary key, " +
                LoginTable.COL_PASSWORD + ")");

        // Create weight table with foreign key that cascade deletes
        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_DATE + " primary key, " +
                WeightTable.COL_WEIGHT + " int, " +
                WeightTable.COL_GOAL_WEIGHT + " int, " +
                WeightTable.COL_USERNAME + ", " +
                "foreign key(" + WeightTable.COL_USERNAME + ") references " +
                LoginTable.TABLE + "(" + LoginTable.COL_USERNAME + ") on delete cascade)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        onCreate(db);
    }

    @Override
    public void onOpen(SQLiteDatabase db) {
        super.onOpen(db);
        if (!db.isReadOnly()) {
            // Enable foreign key constraints
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN) {
                db.execSQL("pragma foreign_keys = on;");
            } else {
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }
    */
}
