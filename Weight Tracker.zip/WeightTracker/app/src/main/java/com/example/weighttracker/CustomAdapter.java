package com.example.weighttracker;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Observer;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

    private ArrayList<HashMap<String, String>> mLocalDataSet;
    private int mSelectedPosition;
    private Button mEditButton;

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private final TextView dateListText;
        private final TextView weightListText;

        public ViewHolder(View view) {
            super(view);
            // Define click listener for the ViewHolder's View
            view.setOnClickListener(this);

            dateListText = (TextView) view.findViewById(R.id.dateListText);
            weightListText = (TextView) view.findViewById(R.id.weightListText);
        }

        // return textviews
        public TextView getDateListText() { return dateListText; }
        public TextView getWeightListText() { return weightListText; }

        @Override
        public void onClick(View view) {
            // Below line is just like a safety check, because sometimes holder could be null,
            // in that case, getAdapterPosition() will return RecyclerView.NO_POSITION
            if (getAdapterPosition() == RecyclerView.NO_POSITION) return;

            // Updating old as well as new positions
            notifyItemChanged(mSelectedPosition);
            mSelectedPosition = getAdapterPosition();
            notifyItemChanged(mSelectedPosition);
            mEditButton.setEnabled(true);
        }

    }

    // Initialize dataset of adapter using arraylist
    public CustomAdapter(ArrayList<HashMap<String, String>> dataSet, Button edit) {
        mEditButton = edit;
        mLocalDataSet = dataSet;
        mSelectedPosition = RecyclerView.NO_POSITION;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int viewType) {
        // Create a new view, which defines the UI of the list item
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_item, viewGroup, false);
        return new ViewHolder(view);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(ViewHolder viewHolder, final int position) {

        // Get element from your dataset at this position and replace the
        // content of the views with that element
        HashMap<String, String> weight = mLocalDataSet.get(position);
        viewHolder.getDateListText().setText(weight.get("DATE"));
        viewHolder.getWeightListText().setText(weight.get("WEIGHT"));

        // Here I am just highlighting the background
        viewHolder.itemView.setBackgroundColor(mSelectedPosition == position ? Color.CYAN : Color.TRANSPARENT);

    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return mLocalDataSet.size();
    }

    // Return the weight item at selected position
    public HashMap<String, String> getItem() {
        return mLocalDataSet.get(mSelectedPosition);
    }

    // Return the selected item position; used for deleting from arraylist
    public int getSelectedItemPosition() {
        return mSelectedPosition;
    }

}