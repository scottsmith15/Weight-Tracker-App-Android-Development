package com.example.weighttracker;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import java.text.DateFormat;

@Entity(tableName = "weights",
        foreignKeys = @ForeignKey(entity = Login.class,
                parentColumns = "username",
                childColumns = "username"))
public class Weight {

    @PrimaryKey(autoGenerate = true)
    @NonNull
    @ColumnInfo(name = "id")
    private long mId;
    @ColumnInfo(name = "date_ms")
    private long mDateMs;
    @ColumnInfo(name = "date")
    private String mDate;
    @ColumnInfo(name = "weight")
    private int mWeight;
    @ColumnInfo(name = "username")
    private String mUsername;


    public Weight(int weight, String username) {
        mDateMs = System.currentTimeMillis();
        mDate = DateFormat.getDateInstance(DateFormat.SHORT).format(mDateMs);
        mWeight = weight;
        mUsername = username;
    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public void setDateMs(long dateMs) {
        mDateMs = dateMs;
    }

    public long getDateMs() {
        return mDateMs;
    }

    public void setDate(String date) {
        mDate = date;
    }

    public String getDate() {
        return mDate;
    }

    public void setWeight(int weight) {
        mWeight = weight;
    }

    public int getWeight() {
        return mWeight;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }

}
